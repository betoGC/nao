import numpy as np
import random
 
np.set_printoptions(formatter={'float': lambda x: "{0:10.4f}".format(x)},linewidth=500)

#Generate matrix here
#nbas = 6
#A    = np.zeros((nbas,nbas))
#for i in range(nbas):
#  for j in range(nbas):
#    A[i,j] = random.uniform(-1.00000,1.00000)

#A[:,100] = A[:,99]

A    = np.asarray([[0.0000,1.0000,2.0000],[1.0000,2.0000,0.0000],[2.0000,0.0000,1.0000]])
nbas = len(A[:,0])
R    = np.zeros((nbas,nbas))
T    = np.identity(nbas)

print("Intitial matrix A","\n",A)
nvalence=0
R[:,0:nvalence] = A[:,0:nvalence].copy()
print("R initially partitioned","\n",R)

#for j in range(nbas):
for j in range(nbas):
  factor = np.zeros(nbas)
  for i in range(nbas):
    if( i < j ):
     proj   = np.dot(R[:,i],A[:,j])
     norm   = np.dot(R[:,i],R[:,i])
     T[i,j] = proj/norm
     factor -= R[:,i]*T[i,j]
     if norm < 1.0E-10 :
      print("Linear dependency between i,j",i,j,norm)
      exit()
  R[:,j] = A[:,j]+factor
    
print("Orthogonal R","\n",R)
print("Transformation T","\n",T)

#Normalization of the new vectors
#for j in range(nbas):
for j in range(nvalence,nbas):
  norm = np.dot(R[:,j],R[:,j])
  norm = 1.0/np.sqrt(norm)
  R[:,j]*=norm
print("Normalized R","\n",R)

#Evaluating properties
print("cols are orthonormal")
S = np.zeros((nbas,nbas))
E = np.identity(nbas)
for i in range(nbas):
  for j in range(nbas): 
    factor = 0.0
    for alpha in range(nbas):
      factor += R[alpha,i]*R[alpha,j]
    S[i,j] = factor

#print("S_03 Must be 0.000",np.matmul(R[:,0],R[:,3]))
#print("S_13 Must be 0.000",np.matmul(R[:,1],R[:,3]))
#print("S_23 Must be 0.000",np.matmul(R[:,2],R[:,3]))
print("Overlaping","\n",S)
